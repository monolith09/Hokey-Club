# Hockeys

# [ click here to open Figma Online](https://www.figma.com/file/oYDXrB8AmDf8NzeUtztSCT/Assignment-3-UI-Design?type=design&node-id=1%3A5&mode=design&t=QlGT7WmNH4hO3VjZ-1)

# [ click here to open All Resources drive ](https://drive.google.com/drive/folders/1FMYXxf1k5-Fd8dNM_0BvQIZE_cPHEtDP)

# [ Figma Link :](https://www.figma.com/file/oYDXrB8AmDf8NzeUtztSCT/Assignment-3-UI-Design?type=design&node-id=1%3A5&mode=design&t=QlGT7WmNH4hO3VjZ-1)(https://www.figma.com/file/oYDXrB8AmDf8NzeUtztSCT/Assignment-3-UI-Design?type=design&node-id=1%3A5&mode=design&t=QlGT7WmNH4hO3VjZ-1)
